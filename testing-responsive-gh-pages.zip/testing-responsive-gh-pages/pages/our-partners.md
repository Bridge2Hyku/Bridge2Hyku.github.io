---
layout: page-fullwidth
subheadline:  "Join our community"
title:  "Our Partners"
permalink: "/our-partners/"
header: no
---

<div class="row">
    <div class="small-12 columns">
        <h3>Bridge2Hyku's Core Contributors</h3>
    </div><!-- /.small-12.columns -->
</div>

<div class="row">
  <div class="large-4 columns">
      <img src="/testing-responsive/images/logo-uh.png">
  </div>
  <div class="large-4 columns">
      <img src="/testing-responsive/images/logo-uvic.png">
  </div>
  <div class="large-4 columns">
      <img src="/testing-responsive/images/logo-um.png">
  </div>
    <div class="row">
  <div class="large-4 columns">
      <img src="/testing-responsive/images/logo-iupui.png">
  </div>
    
  
