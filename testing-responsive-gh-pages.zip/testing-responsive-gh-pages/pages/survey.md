---
title: "A website that doesn't exit"
layout: redirect
sitemap: false
permalink: /survey/
redirect_to:  "https://t.co/NoPMvtxtWX"
---
This is just a page to demonstrate the `redirect`-layout, programmend by [Kanishk](http://codingtips.kanishkkunal.in/about/).
